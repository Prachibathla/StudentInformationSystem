public interface Grading {
    char calculateGrade(int marks);
}
